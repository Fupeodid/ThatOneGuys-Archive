the changes.txt was an example test on scary baboon so uh sigma


basically this is whst u do

python t.py base_2.apk

replace base_2.apk with the apk name make sure the apk is in the same directory as the .py aka in downloads or whatever lmao